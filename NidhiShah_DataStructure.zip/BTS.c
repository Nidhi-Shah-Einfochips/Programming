#include<stdio.h>
#include<stdlib.h>
struct node
{
int data;
struct node* left;
struct node* right;
};
struct node* find_min(struct node *root)
{
	if(root==NULL)
		return NULL;
	else if(root->left!=NULL)
		return find_min(root->left);
	return root;
}
struct node* search(struct node *root, int x)
{
if(root==NULL||root->data==x)
return root;
else if(x>root->data)
return search(root->right,x);
else
return search(root->left,x);
}
struct node *newnode(int x)
{
struct node *p;
p=(struct node *)malloc(sizeof(struct node));
p->data=x;
p->left=NULL;
p->right=NULL;
return p;
}
struct node *insert(struct node *root,int x)
{
if(root==NULL)
return newnode(x);
else if(x>root->data)
root->right=insert(root->right,x);
else
root->left=insert(root->left,x);
return root;
}
void inorder(struct node *root)
{
	if(root==NULL)
		printf("Empty");
	else
	{
		
		if(root->left!=NULL)
		{
			inorder(root->left);
			
		}
		printf("%d ",root->data);
		if(root->right!=NULL)
		{
			inorder(root->right);
		}
	}
}
struct node* delete(struct node* root,int x)
{
	if(root==NULL)
	{
	printf("Empty\n");
	return NULL;
	}
	else
	{
		if(x>root->data)
		root->right=delete(root->right,x);
		else if(x<root->data)
		root->left=delete(root->left,x);
		else
		{
			if(root->left==NULL&&root->right==NULL)
			{
				free(root);
				return 	NULL;
			}
			else if(root->left==NULL||root->right==NULL)
			{
				struct node *temp;
				if(root->left==NULL)
				temp=root->right;
				else
				temp=root->left;
				free(root);
				return temp;
			}
			else
			{
				struct node *temp=find_min(root->right);
				root->data=temp->data;
				root->right=delete(root->right,temp->data);
			}
		}
		return root;
	}
		
}
	
int main()
{
struct node *root;
root=newnode(50);
insert(root,25);
insert(root,75);
insert(root,22);
insert(root,40);
insert(root,60);
insert(root,80);
insert(root,90);
insert(root,15);
insert(root,30);
printf("inorder\n");
inorder(root);
printf("\n");
printf("After deleting 15\n");
root =delete(root,15);
inorder(root);
printf("\n");
printf("After deleting 40\n");
root =delete(root,40);
inorder(root);
printf("\n");
return 0;
}

