#include<stdio.h>  
#include<stdlib.h>  
struct node   
{  
    int data;
    struct node *prev;	  
    struct node *next;   
};  
struct node *head; 
void beginsert ();   
void lastinsert ();  
void randominsert();  
void begin_delete();  
void last_delete();  
void random_delete(); 
void display(); 
void main ()  
{  
    int choice =0;  
    while(choice != 8)   
    {  
        printf("\nChoose one option from the following list ...\n");  
        printf("\n1.Insert in begining\n2.Insert at last\n3.Insert at any random location\n4.Delete from Beginning\n5.Delete from last\n6.Delete node after specified location\n7.Display\n8.Quit");  
        printf("\nEnter your choice?\n");         
        scanf("\n%d",&choice);  
        switch(choice)  
        {  
            case 1:  
            beginsert();      
            break;  
            case 2:  
            lastinsert();         
            break;  
            case 3:  
            randominsert();       
            break;  
            case 4:  
            begin_delete();       
            break;  
            case 5:  
            last_delete();        
            break;  
            case 6:  
            random_delete();          
            break; 
            case 7:
            display();
            break;
	    case 8:  
            exit(0);  
            break;  
            default:  
            printf("Please enter valid choice..");  
        }  
    }  
}  
void beginsert()  
{  
    struct node *ptr;  
    int item;  
    ptr = (struct node *) malloc(sizeof(struct node *));  
    if(ptr == NULL)  
    {  
        printf("\nOVERFLOW");  
    }  
    else  
    {  
        printf("\nEnter value\n");    
        scanf("%d",&item);
	if(head==NULL)
	{
		ptr->next=NULL;
		ptr->prev=NULL;
		ptr->data=item;
		head=ptr;
	}
	else
	{    
        ptr->data = item; 
	ptr->prev=NULL; 
        ptr->next = head;  
        head->prev = ptr;
	head=ptr;
	}  
        printf("\nNode inserted");  
    }  
      
}  
void lastinsert()  
{  
    struct node *ptr,*temp;  
    int item;     
    ptr = (struct node*)malloc(sizeof(struct node));      
    if(ptr == NULL)  
    {  
        printf("\nOVERFLOW");     
    }  
    else  
    {  
        printf("\nEnter value?\n");  
        scanf("%d",&item);  
        ptr->data = item;  
        if(head == NULL)  
        {  
            ptr -> next = NULL;  
	    ptr->prev=NULL;
            head = ptr;   
        }  
        else  
        {  
            temp = head;  
            while (temp -> next != NULL)  
            {  
                temp = temp -> next;  
            }  
            temp->next = ptr; 
	    ptr->prev=temp; 
            ptr->next = NULL;  
          
        }  
    }  
printf("\n node inserted\n");
}  
void randominsert()  
{  
    int i,loc,item;   
    struct node *ptr, *temp;  
    ptr = (struct node *) malloc (sizeof(struct node));  
    if(ptr == NULL)  
    {  
        printf("\nOVERFLOW");  
    }  
    else  
    {  
	temp=head;
        printf("\nEnter the location after which you want to insert ");  
        scanf("\n%d",&loc);   
        for(i=0;i<loc;i++)  
        {  
            temp = temp->next;  
            if(temp == NULL)  
            {  
                printf("\ncan't insert\n");  
                return;  
            }  
          
        } 
	printf("Enter value");
	scanf("%d",&item);
	ptr->data=item;
	ptr->next=temp->next;
	ptr->prev=temp;    
        temp ->next = ptr; 
	temp->next->prev=ptr;  
        printf("\nNode inserted");  
    }  
}  
void begin_delete()  
{  
    struct node *ptr;  
    if(head == NULL)  
    {  
        printf("\nList is empty\n");  
    }  
    else if(head->next==NULL)   
    {  
        head=NULL; 
        free(head);  
        printf("\nNode deleted\n");  
    } 
    else
    {
	ptr=head;
	head=head->next;
	head->prev=NULL;
	free(ptr);
	printf("\n node deleted\n");
     } 
}  
void last_delete()  
{  
    struct node *ptr,*ptr1;  
    if(head == NULL)  
    {  
        printf("\nlist is empty");  
    }  
    else if(head -> next == NULL)  
    {  
        head = NULL;  
        free(head);  
        printf("\nOnly node deleted\n");  
    }  
          
    else  
    {  
        ptr = head;   
        while(ptr->next != NULL)  
        {    
            ptr = ptr ->next;  
        }  
        ptr->prev->next = NULL;  
        free(ptr);  
        printf("\nDeleted Node\n");  
    }     
}  
void random_delete()  
{  
    struct node *ptr,*temp;  
    int loc,i;    
    printf("\n Enter the location of the node after which you want to perform deletion \n");  
    scanf("%d",&loc);  
    ptr=head;  
    while(ptr->data!=loc)
	ptr=ptr->next;
	if(ptr->next ==NULL)
	{
		printf("Canot delete\n");
	}
	else if(ptr->next->next==NULL)
	{
		ptr->next=NULL;
	}
	else
	{
		temp=ptr->next;
		ptr->next=temp->next;
		temp->next->prev=ptr;
		free(temp);
		printf("node deleted\n");
	}  
} 
void display()  
{  
    struct node *ptr;  
    ptr = head;   
    
        printf("\nprinting values\n");   
        while (ptr!=NULL)  
        {  
            printf("\n%d",ptr->data);  
            ptr = ptr -> next;  
        }  
  
} 
