#include<stdio.h>
int size=4;//bits
int reverseBits(int num)
{
	int count=size-1;
	int temp=num;
	num=num>>1;
	while(num)
	{
		temp<<=1;
		temp|=num&1;
		num>>=1;
		count--;
	}
	temp<<=count;
	return temp;
}
int main()
{
	
	int number=0,rev=0;
	printf("enter the number you want to reverse\n");
	scanf("%u",&number);
	printf("\nBefore:");
	for(int x= size-1;x>=0;x--)
	{
		(number & (1<<x))?printf("1"):printf("0");
	}
	rev=reverseBits(number);
	printf("\nAfter:");
	for(int x= size-1;x>=0;x--)
	{
		(rev & (1<<x))?printf("1"):printf("0");
	}
	printf("\n");
	return 0;
}

