#include<stdio.h>
int main()
{
	int len;
	int count=0;
	char str[100];
	printf("Enter the length of string:");
	scanf("%d",&len);
	char string[len];
	printf("Enter the string:");
	scanf("%s",string);
	for(int i=0;string[i];i++)
	{
		if(count!=0 && str[count]==string[i])
		count--;
		else
		{
			count++;
			str[count]=string[i];
		}
		
	}
	if(count==0)
	printf("Empty String\n");
	else
	{
		for(int i=1;i<=count;i++)
		printf("%c",str[i]);
	}
printf("\n");
return 0;
}
