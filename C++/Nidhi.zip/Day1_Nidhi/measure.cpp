//this code is to measure area and volume of given length width height.
#include<iostream>
using namespace std;
class measure
{
	public:
		int length;
		int height;
		int width;
	void setInput()
	{	
		cout<<"Enter length :";
		cin>>length;
		cout<<"Enter height :";
		cin>>height;
		cout<<"Enter width :";
		cin>>width;
	}
	int area()
	{
		return length*width;
	}
	int volume()
	{
		return length*height*width;
	}
};
int main()
{
	measure obj1,obj2;
	obj1.setInput();
	cout<<"Area = "<<obj1.area()<<endl;
	cout<<"Volume = "<<obj1.volume()<<endl;
	obj2.setInput();
	cout<<"Area = "<<obj2.area()<<endl;
	cout<<"Volume = "<<obj2.volume()<<endl;
	return 0;
}
	
