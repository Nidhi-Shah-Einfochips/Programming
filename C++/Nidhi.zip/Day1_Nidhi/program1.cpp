//This is simple code to get square of the number.
#include<iostream>
using namespace std;
int main()
{
	int i;
	cout<<"this is output.\n";
	cout<<"Enter a number:";
	cin>>i;
	cout<<i<<"Squared is"<<i*i<<"\n";
	return 0;
}
