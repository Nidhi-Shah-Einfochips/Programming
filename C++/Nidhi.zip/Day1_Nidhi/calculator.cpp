//This code is for calculating different arthmetic operation here add function is done with returing onject and sub function is done with defining function outside the class.And switch case is use for different operations.
#include<iostream>
using namespace std;
class calculator{
	public:
		int input1;
		int input2;
		void setInput()
		{
			cout<<"Enter first Number:";
			cin>>input1;
			cout<<"Enter second Number:";
			cin>>input2;
		}
		void get()
		{	
			cout<<"Enter first Number:";
			cin>>input1;
		}	
		calculator add(calculator obj1,calculator obj2)
		{
			calculator obj3;
			obj3.input1=obj1.input1+obj2.input1;
			obj3.input2=obj1.input2+obj2.input2;			
			return obj3;
		}
		int sub();
		int mul()
		{
			return input1*input2;
		}
		int div()
		{
			return input1/input2;
		}
		int mod()
		{
			return input1%input2;
		}
		int fact()
		{
			int fact=1;
			for(int i=1;i<=input1;i++)
			{
				fact=fact*i;
			}
			return fact;
		}
};
int main()
{
	int choice;
	calculator obj1,obj2,obj3;
	cout<<"1. Addition of two numbers\n2.subtraction of two numbers\n3.Multiplication of two numbers\n4.division of two numbers\n5.modulo of two numbers\n6.factorial of a number\n7.exit";
	while(choice!=7)
	{
		cout<<"\nEnter choice\n";
		cin>>choice;
		switch(choice)
		{
			case 1:
			obj1.setInput();
			obj2.setInput();
			cout<<"Addition of ";
			cout<<obj1.input1<<" + "<<obj2.input2<<" = ";
			obj3=obj1.add(obj1,obj2);

			break;
			case 2:
			obj1.setInput();
			cout<<"subtraction of "<<obj1.input1<<" - "<<obj1.input2<<" = "<<obj1.sub()<<endl;
			break;
			case 3:
			obj1.setInput();
			cout<<"Multiplication of "<<obj1.input1<<" * "<<obj1.input2<<" = "<<obj1.mul()<<endl;
			break;
			case 4:
			obj1.setInput();
			cout<<"Division of "<<obj1.input1<<" / "<<obj1.input2<<" = "<<obj1.div()<<endl;
			break;
			case 5:
			obj1.setInput();
			cout<<"Modulo of "<<obj1.input1<<" % "<<obj1.input2<<" = "<<obj1.mod()<<endl;
			break;
			case 6:
			obj1.get();
			cout<<"Factorial of "<<obj1.input1<<"! ="<<obj1.fact()<<endl;
			break;
			case 7:
			printf("Thank you\n");
			break;
		}
	}
	return 0;
}
int calculator:: sub()
		{
			return input1-input2;
		}
