//This is code to calulate the sleep time here it takes current time from set rime function and user time from get time function and then it calculate thedifferences between current time and user time with help of function sleep time.
#include<iostream>
#include<ctime>
using namespace std;
class Time
{
	private:
		int hours;
		int minute;
		int second;
	public:
		Time(int h=0,int m=0,int s=0);
		void setTime();
		void getTime(int h=0,int m=0,int s=0);
		Time sleepTime(Time,Time);	
};

class Date
{
	public:
		int day;
		int month;
		int year;

		Date(int d=0,int mm=0,int y=0);
		void setDate();
		void getDate(int d=0,int mm=0,int y=0);
		void setDoB(int d=0,int mm=0,int y=0);
		Date findage(Date);
};

Time::Time(int h,int m,int s)
{
	hours=h;
	minute=m;
	second=s;
}

void Time::setTime()// This function is to get current time
{
	time_t now=time(0);
	tm *ltm=localtime(&now);
	int h=ltm->tm_hour;
	int m=ltm->tm_min;
	int s=ltm->tm_sec;
	
	hours=h;
	minute=m;
	second=s;
	cout<<"Current Time is : "<<hours<<":"<<minute<<":"<<second<<endl;
}

void Time::getTime(int h,int m,int s)//This will get time from user
{
	hours=h;
	minute=m;
	second=s;
	cout<<"User Time is : "<<hours<<":"<<minute<<":"<<second<<endl;
}

Time Time::sleepTime(Time t1,Time t2)//This function is to calculate differernce between Current time and user time and evaluate sleep time
{
		Time T;
		T.second=t1.second-t2.second;
		T.minute=t1.minute-t2.minute+(T.second/60);
		T.hours=t1.hours-t2.hours+(T.minute/60);
		T.minute =T.minute%60;
		T.second =T.second%60;		
		cout<<"Time diffrence is : "<<T.hours<<":"<<T.minute<<":"<<T.second<<endl;
		return T;	

}

Date::Date(int d,int mm,int y)
{
	day=d;
	month=mm;
	year=y;
}

void Date::setDate()// Get the current date
{
	time_t now=time(0);
	tm *ltm=localtime(&now);
	int d=ltm->tm_mday;
	int mm=1+ltm->tm_mon;
	int y=1900+ltm->tm_year;
	
	day=d;
	month=mm;
	year=y;
	cout<<"Current date is : "<<day<<"-"<<month<<"-"<<year<<endl;
}

void Date::getDate(int d,int mm,int y)
{
	day=d;
	month=mm;
	year=y;
	cout<<"User date is : "<<day<<"-"<<month<<"-"<<year<<endl;
}

void Date::setDoB(int d,int mm,int y)// to get date of birth
{
	day=d;
	month=mm;
	year=y;
	cout<<"Date of Birth is : "<<day<<"-"<<month<<"-"<<year<<endl;
}

Date Date::findage(Date dob)//Finds the age of user
{
	Date D;
	D.year=year-dob.year;
	cout<<"Age is : "<<D.year<<endl;
	return D;
}

int main()
{
	Time t1;
	t1.setTime();
	Time t2;
	t2.getTime(16,34,12);
	Time T;
	T=t1.sleepTime(t1,t2);
	
	Date d1;
	d1.setDate();
	Date d2;
	d2.setDoB(27,02,2000);
	Date D;
	D=d1.findage(d2);
	
	return 0;
}

