//This code is for understanding of access specifier
#include<iostream>
using namespace std;
class Myclass
{
	public:// public access specifier
		int x;//public attribute
	private://private access specifier
		int y;//private attribute
};
int main()
{
	Myclass myobj;
	myobj.x=25;//Allowed(public)
	myobj.y=50;//not allowed (private)
	return 0;
}
