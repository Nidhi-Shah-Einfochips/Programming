// BY NIDHI SHAH
// THIS CODE IS TO SHOW INLINE FUNCTION
//
#include<iostream>
using namespace std;

	
inline int  cube(int n)
	{
		return n*n*n;
	}

int main()
{
	
	cout<<cube(5);
	return 0;
}
